//Name: Daniela Travieso
//Class: COP3502
//Section: 6909, Erik
//Project 5: Autograder
//ID: 95953348

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class UndergraduateStudent extends Student 
{
	private String major;
	
	public UndergraduateStudent(String name, String id, String essay, ArrayList<String> errorList, String major)
	{
		super(name, id, essay, errorList);
		this.major = major;
	}

	public String getMajor()
	{
		return major;
	}
	
	public void setMajor(String major)
	{
		this.major = major;
	}

	public void writeToFile()
	{
		//create file to store error list
		File response = new File(getId() + "_graded.txt");
		PrintWriter fileMaker = null;
		
		try {
			//try to make file
			fileMaker = new PrintWriter(response);
			String i = getId();
			String m = getMajor();
			//print to the file
			fileMaker.println("Undergraduate Student " + getName());
			fileMaker.println("Student ID: " + i);
			fileMaker.println("Major: " + m);
			fileMaker.println(this.getPrintableErrorList());
			//super.getPrintable.. versus getPrintable...
			fileMaker.close();
		} catch (FileNotFoundException e) {
			//if the file could not be written
			System.out.println("File could not be written");
			e.printStackTrace();
		}
	
		
		 
	}

}
