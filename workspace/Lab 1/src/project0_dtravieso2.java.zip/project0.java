//Name: Daniela Travieso
//UFL ID: 95953348
//Section: 6909
//Project Number: 0
//Brief description of file contents: Debugging Practice


public class project0 {
	public static void main(String[] args){
		int pounds = 150;
				System.out.println("The boy weighs " + pounds + " pounds.");
				System.out.println("1");
				System.out.println("1" + " " + "2");
				System.out.println("1" + " " + "2"+ " " + "3");
				
		/*Code that is written well can be easily communicated with a team, advisor, or any other person
		 *"Badly" stylized code is like a Cuban who travels to Spain.
		 *Sure, you both speak Spanish, however the nuances and the stylistic/regional differences 
		 *make it so that you have difficulties in exchanging information or understanding the way each
		 *other speaks
		 */
	}
		
}
