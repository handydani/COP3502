
public class Shape 
{

	static String color;
	public Shape(String clr)
	{
		color = clr;
	}
	
	public String getColor()
	{
		return color;
	}
}
